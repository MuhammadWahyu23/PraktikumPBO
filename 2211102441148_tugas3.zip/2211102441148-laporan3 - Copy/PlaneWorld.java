/**
 * Write a description of class PlaneWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface PlaneWorld  
{
    public ScoreBoard getScoreBoard();
}
